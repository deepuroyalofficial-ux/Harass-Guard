package com.example.ai

import com.example.model.AutoModConfig
import com.example.model.Comment
import com.example.model.HarassmentCategory
import com.example.model.ModerationStatus
import com.example.model.RiskLevel
import com.example.model.SentimentType
import java.util.Locale

data class TextAnalysisResult(
    val toxicityScore: Float,
    val sentiment: SentimentType,
    val sentimentScore: Float,
    val categories: Set<HarassmentCategory>,
    val riskLevel: RiskLevel,
    val offendingTokens: List<String>,
    val recommendedStatus: ModerationStatus,
    val explanation: String,
    val categoryBreakdown: Map<HarassmentCategory, Float>
)

object HarassGuardEngine {

    // Toxic & harassment patterns
    private val hateTokens = setOf(
        "hate", "scum", "subhuman", "freak", "disgusting", "creature", "vermin", "parasite", "racist", "bigot"
    )

    private val threatTokens = setOf(
        "kill", "die", "dox", "doxx", "destroy", "murder", "beat", "hunt", "burn", "attack", "kys", "shoot", "stab"
    )

    private val cyberbullyingTokens = setOf(
        "ugly", "loser", "worthless", "fat", "stupid", "idiot", "kill yourself", "clown", "pathetic",
        "nobody likes you", "get lost", "uninstall life", "delete channel", "crybaby", "fake", "cringe"
    )

    private val insultTokens = setOf(
        "trash", "garbage", "moron", "dumb", "noob", "suck", "sucks", "awful", "terrible", "worst", "waste"
    )

    private val profanityTokens = setOf(
        "damn", "hell", "crap", "bastard", "bitch", "ass", "sh*t", "f*ck", "fuk", "wtf"
    )

    private val spamTokens = setOf(
        "free crypto", "free vbucks", "follow back", "click link", "t.me/", "bit.ly", "dm me for promo",
        "check bio", "earn cash fast", "sub4sub"
    )

    private val positiveTokens = setOf(
        "great", "love", "amazing", "awesome", "good", "pog", "poggers", "goat", "gg", "nice",
        "hype", "wholesome", "win", "clutch", "cool", "epic", "best", "legend", "fire", "king", "queen",
        "beautiful", "thank", "thanks", "congrats", "support"
    )

    fun analyze(text: String, config: AutoModConfig = AutoModConfig()): TextAnalysisResult {
        val lowerText = text.lowercase(Locale.ROOT).trim()
        val tokens = lowerText.split(Regex("[\\s,.;!?\"'()\\[\\]{}]+")).filter { it.isNotBlank() }

        val foundOffending = mutableListOf<String>()
        val categories = mutableSetOf<HarassmentCategory>()
        val categoryBreakdown = mutableMapOf<HarassmentCategory, Float>()

        var threatScore = 0.0f
        var hateScore = 0.0f
        var bullyScore = 0.0f
        var insultScore = 0.0f
        var profanityScore = 0.0f
        var spamScore = 0.0f

        // Check explicit custom blocked keywords
        config.blockedKeywords.forEach { kw ->
            if (lowerText.contains(kw.lowercase(Locale.ROOT))) {
                foundOffending.add(kw)
                bullyScore += 0.5f
                threatScore += 0.4f
                categories.add(HarassmentCategory.CYBERBULLYING)
            }
        }

        // Check tokens and phrases
        tokens.forEach { token ->
            if (threatTokens.contains(token)) {
                foundOffending.add(token)
                threatScore += 0.45f
                categories.add(HarassmentCategory.THREAT)
            }
            if (hateTokens.contains(token)) {
                foundOffending.add(token)
                hateScore += 0.4f
                categories.add(HarassmentCategory.HATE_SPEECH)
            }
            if (cyberbullyingTokens.contains(token)) {
                foundOffending.add(token)
                bullyScore += 0.35f
                categories.add(HarassmentCategory.CYBERBULLYING)
            }
            if (insultTokens.contains(token)) {
                foundOffending.add(token)
                insultScore += 0.25f
                categories.add(HarassmentCategory.HARASSMENT)
            }
            if (profanityTokens.contains(token)) {
                foundOffending.add(token)
                profanityScore += 0.25f
                categories.add(HarassmentCategory.PROFANITY)
            }
        }

        // Check multi-word cyberbullying phrases
        cyberbullyingTokens.forEach { phrase ->
            if (phrase.contains(" ") && lowerText.contains(phrase)) {
                foundOffending.add(phrase)
                bullyScore += 0.55f
                categories.add(HarassmentCategory.CYBERBULLYING)
            }
        }

        spamTokens.forEach { spamPattern ->
            if (lowerText.contains(spamPattern)) {
                foundOffending.add(spamPattern)
                spamScore += 0.6f
                categories.add(HarassmentCategory.SPAM)
            }
        }

        // Calculate sentiment
        var positiveScore = 0.0f
        tokens.forEach { token ->
            if (positiveTokens.contains(token)) {
                positiveScore += 0.3f
            }
        }

        // Normalize scores
        threatScore = threatScore.coerceIn(0.0f, 1.0f)
        hateScore = hateScore.coerceIn(0.0f, 1.0f)
        bullyScore = bullyScore.coerceIn(0.0f, 1.0f)
        insultScore = insultScore.coerceIn(0.0f, 1.0f)
        profanityScore = profanityScore.coerceIn(0.0f, 1.0f)
        spamScore = spamScore.coerceIn(0.0f, 1.0f)

        categoryBreakdown[HarassmentCategory.THREAT] = threatScore
        categoryBreakdown[HarassmentCategory.HATE_SPEECH] = hateScore
        categoryBreakdown[HarassmentCategory.CYBERBULLYING] = bullyScore
        categoryBreakdown[HarassmentCategory.HARASSMENT] = insultScore
        categoryBreakdown[HarassmentCategory.PROFANITY] = profanityScore
        categoryBreakdown[HarassmentCategory.SPAM] = spamScore

        // Aggregate toxicity
        val maxComponent = maxOf(threatScore, hateScore, bullyScore, insultScore, profanityScore, spamScore)
        val sumComponent = (threatScore * 1.0f) + (hateScore * 0.9f) + (bullyScore * 0.85f) +
                (insultScore * 0.6f) + (profanityScore * 0.4f) + (spamScore * 0.5f)

        var totalToxicity = (maxComponent * 0.65f + (sumComponent * 0.35f)).coerceIn(0.0f, 1.0f)

        // Mitigation if heavily positive context without severe threats
        if (threatScore < 0.2f && hateScore < 0.2f && positiveScore > 0.4f) {
            totalToxicity = (totalToxicity - 0.25f).coerceAtLeast(0.0f)
        }

        // Sentiment determination
        val sentimentScore = (positiveScore - totalToxicity).coerceIn(-1.0f, 1.0f)
        val sentiment = when {
            sentimentScore > 0.15f -> SentimentType.POSITIVE
            sentimentScore < -0.15f -> SentimentType.NEGATIVE
            else -> SentimentType.NEUTRAL
        }

        if (categories.isEmpty() && totalToxicity < 0.15f) {
            categories.add(HarassmentCategory.NONE)
        }

        // Determine Risk Level
        val riskLevel = when {
            totalToxicity >= 0.75f || threatScore >= 0.6f || hateScore >= 0.6f -> RiskLevel.CRITICAL
            totalToxicity >= 0.50f -> RiskLevel.HIGH_RISK
            totalToxicity >= 0.25f -> RiskLevel.SUSPICIOUS
            else -> RiskLevel.SAFE
        }

        // Recommended moderation action based on thresholds
        val recommendedStatus = when {
            !config.autoModEnabled -> ModerationStatus.ALLOWED
            totalToxicity >= config.deleteThreshold -> ModerationStatus.QUARANTINED
            totalToxicity >= config.warnThreshold -> ModerationStatus.AUTO_WARNED
            else -> ModerationStatus.ALLOWED
        }

        // Generate AI explanation
        val explanation = when {
            threatScore >= 0.5f -> "CRITICAL VIOLATION: Threatening or violent language detected targeting safety."
            hateScore >= 0.4f -> "HIGH SEVERITY: Identity attack or hate speech tokens identified."
            bullyScore >= 0.4f -> "CYBERBULLYING ALERT: Targeted demeaning and harassment behavior intercepted."
            insultScore >= 0.35f -> "MODERATION FLAG: Excessive hostility or offensive insults detected."
            spamScore >= 0.4f -> "SPAM DETECTED: Commercial link or unsolicited self-promotion pattern."
            totalToxicity > 0.2f -> "SUSPICIOUS CONTENT: Borderline toxicity score requires automated vigilance."
            else -> "SAFE CONTENT: No toxic patterns, threats, or harassment detected. Safe for live broadcast."
        }

        return TextAnalysisResult(
            toxicityScore = totalToxicity,
            sentiment = sentiment,
            sentimentScore = sentimentScore,
            categories = categories,
            riskLevel = riskLevel,
            offendingTokens = foundOffending.distinct(),
            recommendedStatus = recommendedStatus,
            explanation = explanation,
            categoryBreakdown = categoryBreakdown
        )
    }

    fun enrichComment(rawText: String, username: String, platform: com.example.model.StreamPlatform, config: AutoModConfig): Comment {
        val analysis = analyze(rawText, config)
        val isSafeUser = config.safeUsers.any { it.equals(username, ignoreCase = true) }

        val finalStatus = if (isSafeUser && analysis.recommendedStatus != ModerationStatus.QUARANTINED) {
            ModerationStatus.ALLOWED
        } else {
            analysis.recommendedStatus
        }

        // Pick distinct vibrant avatar color based on username hash
        val colors = listOf(
            0xFF8B5CF6, 0xFF3B82F6, 0xFF06B6D4, 0xFF10B981,
            0xFFF59E0B, 0xFFEC4899, 0xFF6366F1, 0xFF14B8A6
        )
        val avatarColor = colors[Math.abs(username.hashCode()) % colors.size]

        return Comment(
            id = "c_${System.currentTimeMillis()}_${(100..999).random()}",
            username = username,
            avatarColorHex = avatarColor,
            text = rawText,
            timestamp = System.currentTimeMillis(),
            platform = platform,
            toxicityScore = analysis.toxicityScore,
            sentiment = analysis.sentiment,
            sentimentScore = analysis.sentimentScore,
            categories = analysis.categories,
            riskLevel = analysis.riskLevel,
            moderationStatus = finalStatus,
            offendingTokens = analysis.offendingTokens,
            aiExplanation = analysis.explanation
        )
    }
}
