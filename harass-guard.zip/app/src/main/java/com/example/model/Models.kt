package com.example.model

enum class StreamPlatform(val displayName: String, val badgeColorHex: Long) {
    TWITCH("Twitch", 0xFF9146FF),
    YOUTUBE("YouTube", 0xFFFF0000),
    TIKTOK("TikTok", 0xFF00F2FE),
    DISCORD("Discord", 0xFF5865F2)
}

enum class HarassmentCategory(val displayName: String, val colorHex: Long) {
    CYBERBULLYING("Cyberbullying", 0xFFF43F5E),
    HATE_SPEECH("Hate Speech", 0xFFDC2626),
    HARASSMENT("Harassment", 0xFFEA580C),
    THREAT("Threat & Violence", 0xFFB91C1C),
    PROFANITY("Profanity", 0xFFF59E0B),
    SPAM("Spam & Abuse", 0xFF6366F1),
    NONE("Safe / Clean", 0xFF10B981)
}

enum class RiskLevel(val label: String, val colorHex: Long) {
    SAFE("Safe", 0xFF10B981),
    SUSPICIOUS("Suspicious", 0xFFF59E0B),
    HIGH_RISK("High Risk", 0xFFF97316),
    CRITICAL("Critical Threat", 0xFFEF4444)
}

enum class SentimentType(val label: String, val emoji: String, val colorHex: Long) {
    POSITIVE("Positive", "😊", 0xFF10B981),
    NEUTRAL("Neutral", "😐", 0xFF94A3B8),
    NEGATIVE("Negative", "😠", 0xFFEF4444)
}

enum class ModerationStatus(val label: String) {
    ALLOWED("Allowed"),
    AUTO_WARNED("User Warned"),
    QUARANTINED("Quarantined"),
    BLOCKED("Message Blocked"),
    MANUAL_REVIEW("Needs Review")
}

data class Comment(
    val id: String,
    val username: String,
    val avatarColorHex: Long,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val platform: StreamPlatform = StreamPlatform.TWITCH,
    val toxicityScore: Float = 0.0f, // 0.0 to 1.0
    val sentiment: SentimentType = SentimentType.NEUTRAL,
    val sentimentScore: Float = 0.0f, // -1.0 to 1.0
    val categories: Set<HarassmentCategory> = emptySet(),
    val riskLevel: RiskLevel = RiskLevel.SAFE,
    var moderationStatus: ModerationStatus = ModerationStatus.ALLOWED,
    val offendingTokens: List<String> = emptyList(),
    val aiExplanation: String = "Comment verified clean by HarassGuard AI."
)

enum class AlertSeverity(val label: String, val colorHex: Long) {
    CRITICAL("CRITICAL", 0xFFEF4444),
    HIGH("HIGH", 0xFFF97316),
    MEDIUM("MEDIUM", 0xFFF59E0B),
    LOW("LOW", 0xFF3B82F6)
}

data class CyberAlert(
    val id: String,
    val timestamp: Long = System.currentTimeMillis(),
    val offender: String,
    val severity: AlertSeverity,
    val category: HarassmentCategory,
    val commentSnippet: String,
    val toxicityScore: Float,
    val isResolved: Boolean = false,
    val actionTaken: String? = null
)

enum class ReportStatus(val label: String, val colorHex: Long) {
    PENDING("Pending Review", 0xFFF59E0B),
    INVESTIGATING("Investigating", 0xFF3B82F6),
    RESOLVED("Action Taken", 0xFF10B981),
    DISMISSED("Dismissed", 0xFF64748B)
}

data class UserIncidentReport(
    val id: String,
    val offenderUsername: String,
    val reportedBy: String = "Moderator",
    val category: HarassmentCategory,
    val urgency: String, // "Immediate", "High", "Medium", "Low"
    val evidenceSnippet: String,
    val notes: String,
    val status: ReportStatus = ReportStatus.PENDING,
    val createdAt: Long = System.currentTimeMillis()
)

data class AutoModConfig(
    val autoModEnabled: Boolean = true,
    val deleteThreshold: Float = 0.70f, // Auto-quarantine above 70%
    val warnThreshold: Float = 0.45f,   // Auto-warn above 45%
    val autoMuteRepeatOffenders: Boolean = true,
    val maxStrikes: Int = 3,
    val blockedKeywords: List<String> = listOf("kys", "die", "trash", "ugly", "loser", "dox", "kill yourself", "worthless"),
    val safeUsers: List<String> = listOf("StreamHost", "Mod_Sarah", "VIP_Dragon", "NightBot")
)

data class StreamAnalytics(
    val totalScanned: Int = 0,
    val safeCount: Int = 0,
    val warnedCount: Int = 0,
    val quarantinedCount: Int = 0,
    val safetyScore: Float = 100f, // 0 - 100
    val positiveCount: Int = 0,
    val neutralCount: Int = 0,
    val negativeCount: Int = 0,
    val harassmentCounts: Map<HarassmentCategory, Int> = emptyMap(),
    val recentToxicityPoints: List<Float> = emptyList() // Last 15 data points
)
