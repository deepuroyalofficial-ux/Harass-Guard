package com.example.data

import com.example.ai.HarassGuardEngine
import com.example.model.AlertSeverity
import com.example.model.AutoModConfig
import com.example.model.Comment
import com.example.model.CyberAlert
import com.example.model.HarassmentCategory
import com.example.model.ModerationStatus
import com.example.model.ReportStatus
import com.example.model.RiskLevel
import com.example.model.StreamAnalytics
import com.example.model.StreamPlatform
import com.example.model.UserIncidentReport
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

class HarassGuardRepository(private val coroutineScope: CoroutineScope) {

    private val _comments = MutableStateFlow<List<Comment>>(emptyList())
    val comments: StateFlow<List<Comment>> = _comments.asStateFlow()

    private val _alerts = MutableStateFlow<List<CyberAlert>>(emptyList())
    val alerts: StateFlow<List<CyberAlert>> = _alerts.asStateFlow()

    private val _reports = MutableStateFlow<List<UserIncidentReport>>(emptyList())
    val reports: StateFlow<List<UserIncidentReport>> = _reports.asStateFlow()

    private val _autoModConfig = MutableStateFlow(AutoModConfig())
    val autoModConfig: StateFlow<AutoModConfig> = _autoModConfig.asStateFlow()

    private val _analytics = MutableStateFlow(StreamAnalytics())
    val analytics: StateFlow<StreamAnalytics> = _analytics.asStateFlow()

    private val _isStreaming = MutableStateFlow(true)
    val isStreaming: StateFlow<Boolean> = _isStreaming.asStateFlow()

    private val _streamSpeedMs = MutableStateFlow(1600L) // Normal speed
    val streamSpeedMs: StateFlow<Long> = _streamSpeedMs.asStateFlow()

    private val _currentPlatform = MutableStateFlow(StreamPlatform.TWITCH)
    val currentPlatform: StateFlow<StreamPlatform> = _currentPlatform.asStateFlow()

    private val userStrikes = mutableMapOf<String, Int>()
    private var streamJob: Job? = null

    // Realistic simulation pool
    private val cleanComments = listOf(
        "GGEZ that was an unreal play! 🔥" to "NinjaGamer",
        "Can we get a replay of that last shot?" to "PixelKnight",
        "W stream as always! Best streamer on the platform." to "LunarVibes",
        "What setup are you currently using for audio?" to "TechGeek_99",
        "POGGERS what a turnaround!!" to "HyperNova",
        "Thanks for the community support, you are the best!" to "CozyCat",
        "Subscribed for 6 months today! Keep grinding!" to "ViperBlade",
        "Wholesome chat today, loving the energy ❤️" to "Sammy_Live",
        "Awesome gameplay, taught me a new technique!" to "AeroFlyer",
        "The graphics in this update look so crisp!" to "NeonRider",
        "Good luck in the tournament tomorrow!" to "ChronoShift"
    )

    private val toxicCommentPool = listOf(
        "You are so trash, just uninstall already idiot" to "TrollBait42",
        "Nobody likes you, why are you even streaming pathetic loser" to "ShadowX_99",
        "kys delete your channel you are worthless" to "VenomousRage",
        "Doxx incoming check your IP address clown" to "CyberMenace",
        "Ugliest player in this lobby, absolutely disgusting creature" to "HaterZero",
        "FREE CRYPTO EARN $500 NOW CLICK bit.ly/scam" to "BotSpam_Promo",
        "I hope something terrible happens to you in real life" to "DarkStalker",
        "Stupid noob get destroyed you suck" to "ToxicRival"
    )

    init {
        // Seed initial comments
        seedInitialData()
        startStreamSimulation()
    }

    private fun seedInitialData() {
        val initialComments = mutableListOf<Comment>()
        cleanComments.take(6).forEach { (msg, user) ->
            val comment = HarassGuardEngine.enrichComment(msg, user, StreamPlatform.TWITCH, _autoModConfig.value)
            initialComments.add(comment)
        }
        val toxicSample = toxicCommentPool[0]
        val flaggedComment = HarassGuardEngine.enrichComment(toxicSample.first, toxicSample.second, StreamPlatform.TWITCH, _autoModConfig.value)
        initialComments.add(flaggedComment)
        _comments.value = initialComments.reversed()

        // Seed an initial alert
        _alerts.value = listOf(
            CyberAlert(
                id = "alert_${System.currentTimeMillis()}",
                offender = toxicSample.second,
                severity = AlertSeverity.HIGH,
                category = HarassmentCategory.CYBERBULLYING,
                commentSnippet = toxicSample.first,
                toxicityScore = flaggedComment.toxicityScore,
                isResolved = false
            )
        )

        // Seed initial incident reports
        _reports.value = listOf(
            UserIncidentReport(
                id = "rep_101",
                offenderUsername = "ShadowX_99",
                reportedBy = "ChatMod_Alpha",
                category = HarassmentCategory.CYBERBULLYING,
                urgency = "High",
                evidenceSnippet = "Nobody likes you, why are you even streaming pathetic loser",
                notes = "Repeated harassment targeted at streamer during live match.",
                status = ReportStatus.PENDING,
                createdAt = System.currentTimeMillis() - 120_000
            ),
            UserIncidentReport(
                id = "rep_102",
                offenderUsername = "CyberMenace",
                reportedBy = "StreamHost",
                category = HarassmentCategory.THREAT,
                urgency = "Immediate",
                evidenceSnippet = "Doxx incoming check your IP address clown",
                notes = "Threat of doxxing personal location during stream.",
                status = ReportStatus.INVESTIGATING,
                createdAt = System.currentTimeMillis() - 360_000
            )
        )

        recalculateAnalytics()
    }

    fun startStreamSimulation() {
        streamJob?.cancel()
        streamJob = coroutineScope.launch(Dispatchers.Default) {
            while (isActive) {
                if (_isStreaming.value) {
                    delay(_streamSpeedMs.value)
                    generateNextComment()
                } else {
                    delay(500)
                }
            }
        }
    }

    private fun generateNextComment() {
        // 75% clean, 25% toxic/suspicious to demonstrate Harass Guard real-time interception
        val isToxic = (1..100).random() <= 26
        val (text, username) = if (isToxic) {
            toxicCommentPool.random()
        } else {
            cleanComments.random()
        }

        val comment = HarassGuardEngine.enrichComment(
            rawText = text,
            username = username,
            platform = _currentPlatform.value,
            config = _autoModConfig.value
        )

        processIncomingComment(comment)
    }

    fun processIncomingComment(comment: Comment) {
        // Check repeat offender strikes
        if (comment.toxicityScore >= _autoModConfig.value.warnThreshold) {
            val strikes = (userStrikes[comment.username] ?: 0) + 1
            userStrikes[comment.username] = strikes

            if (_autoModConfig.value.autoMuteRepeatOffenders && strikes >= _autoModConfig.value.maxStrikes) {
                comment.moderationStatus = ModerationStatus.BLOCKED
            }

            // Create alert if High Risk or Critical
            if (comment.riskLevel == RiskLevel.HIGH_RISK || comment.riskLevel == RiskLevel.CRITICAL) {
                val alert = CyberAlert(
                    id = "alert_${UUID.randomUUID().toString().take(8)}",
                    offender = comment.username,
                    severity = if (comment.riskLevel == RiskLevel.CRITICAL) AlertSeverity.CRITICAL else AlertSeverity.HIGH,
                    category = comment.categories.firstOrNull { it != HarassmentCategory.NONE } ?: HarassmentCategory.CYBERBULLYING,
                    commentSnippet = comment.text,
                    toxicityScore = comment.toxicityScore,
                    isResolved = false
                )
                _alerts.update { listOf(alert) + it.take(40) }
            }
        }

        _comments.update { current ->
            (listOf(comment) + current).take(150)
        }

        recalculateAnalytics()
    }

    fun toggleStreaming() {
        _isStreaming.update { !it }
    }

    fun setStreamSpeed(speedMs: Long) {
        _streamSpeedMs.value = speedMs
    }

    fun setPlatform(platform: StreamPlatform) {
        _currentPlatform.value = platform
    }

    fun quarantineComment(commentId: String) {
        _comments.update { list ->
            list.map { if (it.id == commentId) it.copy(moderationStatus = ModerationStatus.QUARANTINED) else it }
        }
        recalculateAnalytics()
    }

    fun allowComment(commentId: String) {
        _comments.update { list ->
            list.map { if (it.id == commentId) it.copy(moderationStatus = ModerationStatus.ALLOWED) else it }
        }
        recalculateAnalytics()
    }

    fun warnUser(username: String) {
        userStrikes[username] = (userStrikes[username] ?: 0) + 1
        _comments.update { list ->
            list.map { if (it.username == username) it.copy(moderationStatus = ModerationStatus.AUTO_WARNED) else it }
        }
        recalculateAnalytics()
    }

    fun timeoutUser(username: String) {
        userStrikes[username] = (userStrikes[username] ?: 0) + 2
        _comments.update { list ->
            list.map { if (it.username == username) it.copy(moderationStatus = ModerationStatus.BLOCKED) else it }
        }
        recalculateAnalytics()
    }

    fun banUser(username: String) {
        userStrikes[username] = 999
        _comments.update { list ->
            list.map { if (it.username == username) it.copy(moderationStatus = ModerationStatus.BLOCKED) else it }
        }
        recalculateAnalytics()
    }

    fun injectCustomComment(username: String, text: String) {
        val comment = HarassGuardEngine.enrichComment(
            rawText = text,
            username = username.ifBlank { "User_${(100..999).random()}" },
            platform = _currentPlatform.value,
            config = _autoModConfig.value
        )
        processIncomingComment(comment)
    }

    fun resolveAlert(alertId: String, actionTaken: String = "Resolved by Moderator") {
        _alerts.update { list ->
            list.map { if (it.id == alertId) it.copy(isResolved = true, actionTaken = actionTaken) else it }
        }
    }

    fun clearAllAlerts() {
        _alerts.update { list ->
            list.map { it.copy(isResolved = true, actionTaken = "Batch Cleared") }
        }
    }

    fun createIncidentReport(report: UserIncidentReport) {
        _reports.update { listOf(report) + it }
    }

    fun updateReportStatus(reportId: String, newStatus: ReportStatus) {
        _reports.update { list ->
            list.map { if (it.id == reportId) it.copy(status = newStatus) else it }
        }
    }

    fun updateAutoModConfig(config: AutoModConfig) {
        _autoModConfig.value = config
    }

    fun addBlockedKeyword(keyword: String) {
        val clean = keyword.trim()
        if (clean.isNotBlank() && !_autoModConfig.value.blockedKeywords.contains(clean)) {
            _autoModConfig.update { it.copy(blockedKeywords = it.blockedKeywords + clean) }
        }
    }

    fun removeBlockedKeyword(keyword: String) {
        _autoModConfig.update { it.copy(blockedKeywords = it.blockedKeywords - keyword) }
    }

    private fun recalculateAnalytics() {
        val list = _comments.value
        val total = list.size
        if (total == 0) return

        val safe = list.count { it.moderationStatus == ModerationStatus.ALLOWED && it.riskLevel == RiskLevel.SAFE }
        val warned = list.count { it.moderationStatus == ModerationStatus.AUTO_WARNED }
        val quarantined = list.count { it.moderationStatus == ModerationStatus.QUARANTINED || it.moderationStatus == ModerationStatus.BLOCKED }

        val pos = list.count { it.sentiment == com.example.model.SentimentType.POSITIVE }
        val neu = list.count { it.sentiment == com.example.model.SentimentType.NEUTRAL }
        val neg = list.count { it.sentiment == com.example.model.SentimentType.NEGATIVE }

        val catMap = mutableMapOf<HarassmentCategory, Int>()
        list.forEach { c ->
            c.categories.forEach { cat ->
                catMap[cat] = (catMap[cat] ?: 0) + 1
            }
        }

        // Safety score 0-100%
        val violationCount = warned + (quarantined * 2)
        val safety = ((total - (violationCount.toFloat() * 0.7f)) / total.toFloat() * 100f).coerceIn(0f, 100f)

        // Rolling toxicity points for graph (last 15 comments)
        val toxicityPoints = list.take(15).map { it.toxicityScore }.reversed()

        _analytics.value = StreamAnalytics(
            totalScanned = total,
            safeCount = safe,
            warnedCount = warned,
            quarantinedCount = quarantined,
            safetyScore = safety,
            positiveCount = pos,
            neutralCount = neu,
            negativeCount = neg,
            harassmentCounts = catMap,
            recentToxicityPoints = toxicityPoints
        )
    }
}
