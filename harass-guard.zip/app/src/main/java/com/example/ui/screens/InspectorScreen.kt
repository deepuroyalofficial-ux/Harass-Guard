package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HarassmentCategory
import com.example.model.ModerationStatus
import com.example.ui.components.CyberCard
import com.example.ui.components.ModerationStatusBadge
import com.example.ui.components.RiskBadge
import com.example.ui.components.SentimentIndicator
import com.example.ui.components.ToxicityProgressBar
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CyberBgDark
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceDark
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.HarassGuardViewModel

@Composable
fun InspectorScreen(
    viewModel: HarassGuardViewModel,
    modifier: Modifier = Modifier
) {
    val inputText by viewModel.inspectorInputText.collectAsState()
    val result by viewModel.inspectorResult.collectAsState()

    val presets = listOf(
        "You are such a pathetic loser uninstall right now" to "Cyberbullying",
        "I know your real address, watch your back tonight" to "Threat/Doxx",
        "Disgusting subhuman trash get out of here" to "Hate Speech",
        "Free $500 crypto giveaway click t.me/free_promo" to "Spam Scam",
        "GG wp! That 1v3 clutch was unbelievable legend!" to "Positive Banter"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBgDark)
            .padding(horizontal = 16.dp)
            .testTag("inspector_screen"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp)
    ) {
        // Title Header
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(NeonPurple.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = NeonPurple,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "AI Harassment Inspector",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Real-time NLP toxicity & sentiment breakdown sandbox",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Test Input Box
        item {
            CyberCard(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "INPUT TEXT FOR HARASSMENT SCAN:",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { viewModel.setInspectorInputText(it) },
                        placeholder = { Text("Type or paste message to inspect toxicity...", fontSize = 13.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .testTag("inspector_input_field"),
                        maxLines = 4,
                        trailingIcon = {
                            if (inputText.isNotBlank()) {
                                IconButton(onClick = { viewModel.setInspectorInputText("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextMuted)
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonPurple,
                            unfocusedBorderColor = CyberBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = CyberSurfaceDark,
                            unfocusedContainerColor = CyberSurfaceDark
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Preset Chips
                    Text(
                        text = "Quick Test Presets:",
                        color = TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        presets.forEach { (text, label) ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(CyberSurfaceDark)
                                    .border(1.dp, CyberBorder, RoundedCornerShape(8.dp))
                                    .clickable { viewModel.testInspectorPrompt(text) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = label,
                                    color = CyberCyan,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Analysis Results Card
        item {
            if (result != null) {
                val analysis = result!!

                CyberCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = when (analysis.riskLevel) {
                        com.example.model.RiskLevel.CRITICAL -> AlertRed.copy(alpha = 0.6f)
                        com.example.model.RiskLevel.HIGH_RISK -> WarningAmber.copy(alpha = 0.6f)
                        else -> CyberCyan.copy(alpha = 0.4f)
                    }
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = CyberCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "AI CLASSIFICATION RESULT",
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 0.5.sp
                                )
                            }
                            RiskBadge(riskLevel = analysis.riskLevel)
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Primary Toxicity Progress Bar
                        ToxicityProgressBar(
                            score = analysis.toxicityScore,
                            label = "Overall Harassment Score",
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Sentiment & Mitigation Row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(CyberSurfaceDark)
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = "Detected Sentiment", color = TextMuted, fontSize = 11.sp)
                                Spacer(modifier = Modifier.height(2.dp))
                                SentimentIndicator(sentiment = analysis.sentiment)
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "Auto-Mod Recommendation", color = TextMuted, fontSize = 11.sp)
                                Spacer(modifier = Modifier.height(2.dp))
                                ModerationStatusBadge(status = analysis.recommendedStatus)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Multi-dimensional Category Breakdown
                        Text(
                            text = "Multi-Category Threat Breakdown:",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        listOf(
                            HarassmentCategory.CYBERBULLYING to "Cyberbullying & Demeaning",
                            HarassmentCategory.THREAT to "Violence & Threats",
                            HarassmentCategory.HATE_SPEECH to "Hate Speech & Identity Attack",
                            HarassmentCategory.HARASSMENT to "Insults & Hostility",
                            HarassmentCategory.PROFANITY to "Profanity & Vulgarity",
                            HarassmentCategory.SPAM to "Spam & Malicious Links"
                        ).forEach { (cat, label) ->
                            val catScore = analysis.categoryBreakdown[cat] ?: 0f
                            CategoryBreakdownRow(label = label, score = catScore)
                            Spacer(modifier = Modifier.height(6.dp))
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Offending Keywords Tag Cloud
                        if (analysis.offendingTokens.isNotEmpty()) {
                            Text(
                                text = "Flagged Trigger Tokens:",
                                color = TextMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                analysis.offendingTokens.forEach { token ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(AlertRed.copy(alpha = 0.25f))
                                            .border(1.dp, AlertRed.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = token,
                                            color = AlertRed,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                        }

                        // Explanation Box
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(CyberSurfaceElevated)
                                .padding(12.dp)
                        ) {
                            Text(
                                text = analysis.explanation,
                                color = TextPrimary,
                                fontSize = 12.sp,
                                lineHeight = 17.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Action Button: Inject to Live Stream
                        Button(
                            onClick = {
                                viewModel.injectCustomComment("Inspector_Tester", inputText)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("inspector_inject_stream_button")
                        ) {
                            Icon(imageVector = Icons.Default.Shield, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Simulate In Live Stream Broadcast", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "Enter text above to see AI harassment analysis.", color = TextMuted, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun CategoryBreakdownRow(label: String, score: Float) {
    val barColor = when {
        score >= 0.6f -> AlertRed
        score >= 0.3f -> WarningAmber
        else -> CyberCyan
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, color = TextSecondary, fontSize = 11.sp)
            Text(
                text = "${(score * 100).toInt()}%",
                color = if (score > 0.05f) barColor else TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(3.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(5.dp)
                .clip(RoundedCornerShape(2.5.dp))
                .background(CyberSurfaceDark)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(fraction = score.coerceIn(0f, 1f))
                    .height(5.dp)
                    .clip(RoundedCornerShape(2.5.dp))
                    .background(barColor)
            )
        }
    }
}
