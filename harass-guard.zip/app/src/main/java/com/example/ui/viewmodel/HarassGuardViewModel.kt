package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.HarassGuardEngine
import com.example.ai.TextAnalysisResult
import com.example.data.HarassGuardRepository
import com.example.model.AutoModConfig
import com.example.model.Comment
import com.example.model.CyberAlert
import com.example.model.HarassmentCategory
import com.example.model.ModerationStatus
import com.example.model.ReportStatus
import com.example.model.RiskLevel
import com.example.model.StreamAnalytics
import com.example.model.StreamPlatform
import com.example.model.UserIncidentReport
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import java.util.UUID

enum class CommentFilter(val label: String) {
    ALL("All Messages"),
    FLAGGED("Flagged & Toxic"),
    QUARANTINED("Quarantined"),
    SAFE("Clean")
}

class HarassGuardViewModel : ViewModel() {

    private val repository = HarassGuardRepository(viewModelScope)

    val rawComments: StateFlow<List<Comment>> = repository.comments
    val alerts: StateFlow<List<CyberAlert>> = repository.alerts
    val reports: StateFlow<List<UserIncidentReport>> = repository.reports
    val analytics: StateFlow<StreamAnalytics> = repository.analytics
    val autoModConfig: StateFlow<AutoModConfig> = repository.autoModConfig
    val isStreaming: StateFlow<Boolean> = repository.isStreaming
    val streamSpeedMs: StateFlow<Long> = repository.streamSpeedMs
    val currentPlatform: StateFlow<StreamPlatform> = repository.currentPlatform

    // Filter state for live chat
    private val _selectedFilter = MutableStateFlow(CommentFilter.ALL)
    val selectedFilter: StateFlow<CommentFilter> = _selectedFilter.asStateFlow()

    // Filtered comments
    val filteredComments: StateFlow<List<Comment>> = combine(
        rawComments,
        _selectedFilter
    ) { comments, filter ->
        when (filter) {
            CommentFilter.ALL -> comments
            CommentFilter.FLAGGED -> comments.filter {
                it.toxicityScore >= 0.25f || it.moderationStatus != ModerationStatus.ALLOWED
            }
            CommentFilter.QUARANTINED -> comments.filter {
                it.moderationStatus == ModerationStatus.QUARANTINED || it.moderationStatus == ModerationStatus.BLOCKED
            }
            CommentFilter.SAFE -> comments.filter {
                it.riskLevel == RiskLevel.SAFE && it.moderationStatus == ModerationStatus.ALLOWED
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // AI Text Inspector Sandbox state
    private val _inspectorInputText = MutableStateFlow("You are such a pathetic loser uninstall right now")
    val inspectorInputText: StateFlow<String> = _inspectorInputText.asStateFlow()

    private val _inspectorResult = MutableStateFlow<TextAnalysisResult?>(null)
    val inspectorResult: StateFlow<TextAnalysisResult?> = _inspectorResult.asStateFlow()

    // Incident report creation dialog state
    private val _reportTargetComment = MutableStateFlow<Comment?>(null)
    val reportTargetComment: StateFlow<Comment?> = _reportTargetComment.asStateFlow()

    private val _showReportDialog = MutableStateFlow(false)
    val showReportDialog: StateFlow<Boolean> = _showReportDialog.asStateFlow()

    // AutoMod settings dialog state
    private val _showSettingsDialog = MutableStateFlow(false)
    val showSettingsDialog: StateFlow<Boolean> = _showSettingsDialog.asStateFlow()

    init {
        // Run initial inspection analysis
        analyzeInspectorText(_inspectorInputText.value)
    }

    fun setFilter(filter: CommentFilter) {
        _selectedFilter.value = filter
    }

    fun toggleStreaming() {
        repository.toggleStreaming()
    }

    fun setStreamSpeed(speedMs: Long) {
        repository.setStreamSpeed(speedMs)
    }

    fun setPlatform(platform: StreamPlatform) {
        repository.setPlatform(platform)
    }

    fun quarantineComment(commentId: String) {
        repository.quarantineComment(commentId)
    }

    fun allowComment(commentId: String) {
        repository.allowComment(commentId)
    }

    fun warnUser(username: String) {
        repository.warnUser(username)
    }

    fun timeoutUser(username: String) {
        repository.timeoutUser(username)
    }

    fun banUser(username: String) {
        repository.banUser(username)
    }

    fun injectCustomComment(username: String, text: String) {
        repository.injectCustomComment(username, text)
    }

    fun resolveAlert(alertId: String, actionTaken: String = "Acknowledged & Neutralized") {
        repository.resolveAlert(alertId, actionTaken)
    }

    fun clearAllAlerts() {
        repository.clearAllAlerts()
    }

    // AI Inspector actions
    fun setInspectorInputText(text: String) {
        _inspectorInputText.value = text
        analyzeInspectorText(text)
    }

    private fun analyzeInspectorText(text: String) {
        if (text.isBlank()) {
            _inspectorResult.value = null
        } else {
            _inspectorResult.value = HarassGuardEngine.analyze(text, autoModConfig.value)
        }
    }

    fun testInspectorPrompt(preset: String) {
        _inspectorInputText.value = preset
        analyzeInspectorText(preset)
    }

    // Incident reporting
    fun openReportDialog(comment: Comment? = null) {
        _reportTargetComment.value = comment
        _showReportDialog.value = true
    }

    fun closeReportDialog() {
        _showReportDialog.value = false
        _reportTargetComment.value = null
    }

    fun submitReport(
        offender: String,
        category: HarassmentCategory,
        urgency: String,
        evidence: String,
        notes: String
    ) {
        val newReport = UserIncidentReport(
            id = "rep_${UUID.randomUUID().toString().take(6)}",
            offenderUsername = offender.ifBlank { "Unknown_User" },
            category = category,
            urgency = urgency,
            evidenceSnippet = evidence,
            notes = notes,
            status = ReportStatus.PENDING,
            createdAt = System.currentTimeMillis()
        )
        repository.createIncidentReport(newReport)
        closeReportDialog()
    }

    fun updateReportStatus(reportId: String, newStatus: ReportStatus) {
        repository.updateReportStatus(reportId, newStatus)
    }

    // Settings actions
    fun openSettingsDialog() {
        _showSettingsDialog.value = true
    }

    fun closeSettingsDialog() {
        _showSettingsDialog.value = false
    }

    fun updateAutoModConfig(config: AutoModConfig) {
        repository.updateAutoModConfig(config)
        // re-run inspector with updated config
        analyzeInspectorText(_inspectorInputText.value)
    }

    fun addBlockedKeyword(keyword: String) {
        repository.addBlockedKeyword(keyword)
    }

    fun removeBlockedKeyword(keyword: String) {
        repository.removeBlockedKeyword(keyword)
    }
}
