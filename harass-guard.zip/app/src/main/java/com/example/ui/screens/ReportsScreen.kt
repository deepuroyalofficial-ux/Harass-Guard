package com.example.ui.screens

import android.annotation.SuppressLint
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.ReportStatus
import com.example.model.UserIncidentReport
import com.example.ui.components.CategoryChip
import com.example.ui.components.CyberCard
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CyberBgDark
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceDark
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.HarassGuardViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ReportsScreen(
    viewModel: HarassGuardViewModel,
    modifier: Modifier = Modifier
) {
    val reports by viewModel.reports.collectAsState()
    var selectedViewTab by remember { mutableStateOf(0) } // 0: Native Reports, 1: HTML5/CSS/JS Web Command Portal

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBgDark)
            .testTag("reports_screen")
    ) {
        // Sub-tabs: Native Incident Dossier vs Web Command Portal
        TabRow(
            selectedTabIndex = selectedViewTab,
            containerColor = CyberSurfaceDark,
            contentColor = NeonPurple,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[selectedViewTab]),
                    color = NeonPurple
                )
            }
        ) {
            Tab(
                selected = selectedViewTab == 0,
                onClick = { selectedViewTab = 0 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Assignment, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Incident Dossier (${reports.size})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            )
            Tab(
                selected = selectedViewTab == 1,
                onClick = { selectedViewTab = 1 },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Language, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Web Command Portal", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            )
        }

        if (selectedViewTab == 0) {
            // Native Incident Reports List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Harassment Incident Reports",
                                color = TextPrimary,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Verified harassment case documentation",
                                color = TextMuted,
                                fontSize = 12.sp
                            )
                        }

                        Button(
                            onClick = { viewModel.openReportDialog() },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("file_new_report_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("New Report", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }

                if (reports.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "No user reports filed yet.", color = TextMuted)
                        }
                    }
                } else {
                    items(items = reports, key = { it.id }) { report ->
                        IncidentReportCard(
                            report = report,
                            onUpdateStatus = { newStatus -> viewModel.updateReportStatus(report.id, newStatus) }
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }
            }
        } else {
            // HTML5, CSS3, JavaScript Responsive Web Command Portal
            WebCommandPortalView(modifier = Modifier.fillMaxSize())
        }
    }
}

@Composable
fun IncidentReportCard(
    report: UserIncidentReport,
    onUpdateStatus: (ReportStatus) -> Unit,
    modifier: Modifier = Modifier
) {
    val timeFormat = remember { SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()) }
    val formattedDate = remember(report.createdAt) { timeFormat.format(Date(report.createdAt)) }

    val statusColor = Color(report.status.colorHex)

    CyberCard(
        modifier = modifier.fillMaxWidth(),
        borderColor = CyberBorder
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "CASE #${report.id.uppercase()}",
                        color = CyberCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    CategoryChip(category = report.category)
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(statusColor.copy(alpha = 0.2f))
                        .border(1.dp, statusColor.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = report.status.label,
                        color = statusColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = "Target Offender: ", color = TextMuted, fontSize = 12.sp)
                Text(text = report.offenderUsername, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(12.dp))
                Text(text = "Urgency: ", color = TextMuted, fontSize = 12.sp)
                Text(
                    text = report.urgency,
                    color = if (report.urgency == "Immediate") AlertRed else WarningAmber,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Evidence Snippet Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberSurfaceDark)
                    .padding(10.dp)
            ) {
                Column {
                    Text(text = "ATTACHED EVIDENCE:", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "\"${report.evidenceSnippet}\"",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }
            }

            if (report.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Notes: ${report.notes}",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Status Management Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = formattedDate, color = TextMuted, fontSize = 10.sp, modifier = Modifier.weight(1f))

                if (report.status != ReportStatus.RESOLVED) {
                    OutlinedButton(
                        onClick = { onUpdateStatus(ReportStatus.RESOLVED) },
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = SuccessGreen),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SuccessGreen.copy(alpha = 0.5f))
                    ) {
                        Icon(Icons.Default.Check, null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("Resolve", fontSize = 10.sp)
                    }
                }

                if (report.status != ReportStatus.INVESTIGATING && report.status != ReportStatus.RESOLVED) {
                    OutlinedButton(
                        onClick = { onUpdateStatus(ReportStatus.INVESTIGATING) },
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberBlue),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBlue.copy(alpha = 0.5f))
                    ) {
                        Text("Investigate", fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebCommandPortalView(modifier: Modifier = Modifier) {
    // Interactive HTML, CSS, JavaScript portal for Harass Guard
    val webHtml = remember {
        """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
            <title>Realtime-Streaming Harass Guard</title>
            <style>
                :root {
                    --bg-dark: #0A0716;
                    --surface: #130E26;
                    --surface-card: #241C47;
                    --neon-purple: #8B5CF6;
                    --neon-purple-glow: #A855F7;
                    --cyber-blue: #3B82F6;
                    --cyber-cyan: #06B6D4;
                    --alert-red: #EF4444;
                    --alert-glow: #F87171;
                    --warning-amber: #F59E0B;
                    --success-green: #10B981;
                    --text-primary: #F8FAFC;
                    --text-secondary: #94A3B8;
                }
                * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
                body {
                    background: var(--bg-dark);
                    color: var(--text-primary);
                    padding: 16px;
                    padding-bottom: 90px;
                    overflow-x: hidden;
                }
                .header {
                    background: linear-gradient(135deg, #7C3AED 0%, #2563EB 50%, #06B6D4 100%);
                    border-radius: 16px;
                    padding: 20px;
                    box-shadow: 0 10px 30px rgba(139, 92, 246, 0.3);
                    margin-bottom: 20px;
                    position: relative;
                    overflow: hidden;
                }
                .header h1 { font-size: 20px; font-weight: 900; margin-bottom: 6px; }
                .header p { font-size: 12px; opacity: 0.9; }
                .pulse-tag {
                    display: inline-flex;
                    align-items: center;
                    background: rgba(0,0,0,0.3);
                    border: 1px solid rgba(255,255,255,0.3);
                    border-radius: 20px;
                    padding: 4px 10px;
                    font-size: 11px;
                    font-weight: 700;
                    margin-bottom: 12px;
                }
                .dot { width: 8px; height: 8px; border-radius: 50%; background: #10B981; margin-right: 6px; box-shadow: 0 0 8px #10B981; }
                .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 18px; }
                .card {
                    background: var(--surface);
                    border: 1px solid rgba(168, 85, 247, 0.25);
                    border-radius: 14px;
                    padding: 14px;
                }
                .card-title { font-size: 11px; color: var(--text-secondary); font-weight: 700; text-transform: uppercase; margin-bottom: 6px; }
                .card-val { font-size: 22px; font-weight: 900; color: #FFF; }
                .chart-container {
                    background: var(--surface);
                    border: 1px solid rgba(6, 182, 212, 0.3);
                    border-radius: 14px;
                    padding: 16px;
                    margin-bottom: 18px;
                }
                .chart-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
                .chart-title { font-size: 13px; font-weight: 800; color: var(--cyber-cyan); }
                canvas { width: 100%; height: 120px; }
                .input-group {
                    background: var(--surface);
                    border: 1px solid rgba(139, 92, 246, 0.3);
                    border-radius: 14px;
                    padding: 16px;
                    margin-bottom: 18px;
                }
                input, textarea, select {
                    width: 100%;
                    background: rgba(0,0,0,0.4);
                    border: 1px solid rgba(168, 85, 247, 0.4);
                    border-radius: 8px;
                    padding: 10px;
                    color: #FFF;
                    font-size: 13px;
                    margin-top: 6px;
                    margin-bottom: 12px;
                    outline: none;
                }
                button {
                    background: linear-gradient(90deg, var(--neon-purple), var(--cyber-blue));
                    color: white;
                    border: none;
                    border-radius: 8px;
                    padding: 12px;
                    font-weight: 800;
                    font-size: 13px;
                    width: 100%;
                    cursor: pointer;
                    box-shadow: 0 4px 15px rgba(139, 92, 246, 0.4);
                }
                .result-box {
                    background: rgba(0,0,0,0.5);
                    border: 1px solid rgba(255,255,255,0.1);
                    border-radius: 8px;
                    padding: 12px;
                    margin-top: 12px;
                    display: none;
                }
                .badge {
                    display: inline-block;
                    padding: 3px 8px;
                    border-radius: 4px;
                    font-size: 10px;
                    font-weight: 800;
                }
                .badge-danger { background: rgba(239, 68, 68, 0.3); color: #EF4444; border: 1px solid #EF4444; }
                .badge-success { background: rgba(16, 185, 129, 0.3); color: #10B981; border: 1px solid #10B981; }
                .feed-item {
                    border-left: 3px solid var(--neon-purple);
                    padding: 8px 12px;
                    background: var(--surface);
                    margin-bottom: 8px;
                    border-radius: 0 8px 8px 0;
                    font-size: 12px;
                }
            </style>
        </head>
        <body>
            <div class="header">
                <div class="pulse-tag"><div class="dot"></div> HARASSGUARD WEB STREAM ENGINE</div>
                <h1>AI Realtime Protection Hub</h1>
                <p>Live cyberbullying interception & multi-platform moderation telemetry</p>
            </div>

            <div class="grid">
                <div class="card">
                    <div class="card-title">Safety Health</div>
                    <div class="card-val" id="web-health">95.4%</div>
                </div>
                <div class="card">
                    <div class="card-title">Interceptions</div>
                    <div class="card-val" id="web-intercepts" style="color: var(--alert-glow);">48</div>
                </div>
            </div>

            <div class="chart-container">
                <div class="chart-header">
                    <span class="chart-title">REALTIME TOXICITY SPECTRUM</span>
                    <span style="font-size: 10px; color: var(--text-secondary);">60 FPS LIVE SENSOR</span>
                </div>
                <canvas id="liveChart"></canvas>
            </div>

            <div class="input-group">
                <div class="card-title">Web AI Text Harassment Tester</div>
                <input type="text" id="testInput" value="You are such a loser uninstall your game immediately" placeholder="Enter message to test AI detector...">
                <button onclick="runWebAnalysis()">ANALYZE HARASSMENT THREAT</button>
                <div class="result-box" id="resultBox">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                        <span id="resultScore" style="font-size:14px; font-weight:800;">Toxicity: 88%</span>
                        <span id="resultBadge" class="badge badge-danger">CYBERBULLYING</span>
                    </div>
                    <p id="resultText" style="font-size:12px; color:var(--text-secondary);"></p>
                </div>
            </div>

            <div class="chart-container">
                <div class="chart-header">
                    <span class="chart-title">RECENT AUTOMATED AUDIT TRAIL</span>
                </div>
                <div id="auditFeed">
                    <div class="feed-item"><strong>ShadowX_99</strong> - Auto-quarantined for targeted cyberbullying (Toxicity: 91%)</div>
                    <div class="feed-item"><strong>CyberMenace</strong> - Strike #3 applied: User shadowbanned (Threat: 84%)</div>
                    <div class="feed-item"><strong>BotSpam</strong> - Spam link purged from live chat buffer</div>
                </div>
            </div>

            <script>
                const canvas = document.getElementById('liveChart');
                const ctx = canvas.getContext('2d');
                let points = [15, 22, 18, 30, 25, 40, 85, 30, 22, 19, 14, 28, 75, 20];

                function drawChart() {
                    canvas.width = canvas.clientWidth;
                    canvas.height = canvas.clientHeight;
                    const w = canvas.width;
                    const h = canvas.height;
                    ctx.clearRect(0, 0, w, h);

                    // Grid lines
                    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
                    ctx.beginPath();
                    ctx.moveTo(0, h * 0.3); ctx.lineTo(w, h * 0.3);
                    ctx.moveTo(0, h * 0.7); ctx.lineTo(w, h * 0.7);
                    ctx.stroke();

                    // Line
                    ctx.strokeStyle = '#06B6D4';
                    ctx.lineWidth = 3;
                    ctx.beginPath();
                    const step = w / (points.length - 1);
                    points.forEach((val, i) => {
                        const x = i * step;
                        const y = h - (val / 100 * h);
                        if (i === 0) ctx.moveTo(x, y);
                        else ctx.lineTo(x, y);
                    });
                    ctx.stroke();

                    // Points
                    points.forEach((val, i) => {
                        const x = i * step;
                        const y = h - (val / 100 * h);
                        ctx.fillStyle = val > 70 ? '#EF4444' : (val > 40 ? '#F59E0B' : '#10B981');
                        ctx.beginPath();
                        ctx.arc(x, y, 4, 0, Math.PI * 2);
                        ctx.fill();
                    });
                }

                setInterval(() => {
                    points.shift();
                    points.push(Math.floor(Math.random() * 80) + 10);
                    drawChart();
                }, 1800);
                window.onload = drawChart;

                function runWebAnalysis() {
                    const text = document.getElementById('testInput').value.toLowerCase();
                    const box = document.getElementById('resultBox');
                    const score = document.getElementById('resultScore');
                    const badge = document.getElementById('resultBadge');
                    const desc = document.getElementById('resultText');

                    box.style.display = 'block';

                    if (text.includes('loser') || text.includes('uninstall') || text.includes('die') || text.includes('hate') || text.includes('kys')) {
                        score.innerText = 'Toxicity: 92% (High Severity)';
                        score.style.color = '#EF4444';
                        badge.className = 'badge badge-danger';
                        badge.innerText = 'CYBERBULLYING / THREAT';
                        desc.innerText = 'HarassGuard Engine intercepted toxic terminology. Auto-mod policy: Instant Quarantine & 1 Strike applied.';
                    } else {
                        score.innerText = 'Toxicity: 4% (Clean)';
                        score.style.color = '#10B981';
                        badge.className = 'badge badge-success';
                        badge.innerText = 'SAFE BROADCAST';
                        desc.innerText = 'Zero toxic or offensive patterns detected. Comment cleared for real-time live display.';
                    }
                }
            </script>
        </body>
        </html>
        """.trimIndent()
    }

    AndroidView(
        factory = { context ->
            WebView(context).apply {
                webViewClient = WebViewClient()
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.loadWithOverviewMode = true
                settings.useWideViewPort = true
                loadDataWithBaseURL("https://harassguard.ai", webHtml, "text/html", "UTF-8", null)
            }
        },
        modifier = modifier
    )
}
