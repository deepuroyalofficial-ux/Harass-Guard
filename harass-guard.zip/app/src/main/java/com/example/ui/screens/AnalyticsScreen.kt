package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.HarassmentCategory
import com.example.ui.components.CyberCard
import com.example.ui.components.StatMetricCard
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CyberBgDark
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceDark
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.HarassGuardViewModel

@Composable
fun AnalyticsScreen(
    viewModel: HarassGuardViewModel,
    modifier: Modifier = Modifier
) {
    val analytics by viewModel.analytics.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBgDark)
            .padding(horizontal = 16.dp)
            .testTag("analytics_screen"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp)
    ) {
        // Header
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(CyberCyan.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Analytics,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Live Stream Analytics",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Real-time safety telemetry & incident metrics",
                        color = TextMuted,
                        fontSize = 12.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Safety Gauge Arc Card
        item {
            CyberCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = CyberBorder
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "OVERALL STREAM SAFETY HEALTH",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Circular Arc Gauge
                    Box(
                        modifier = Modifier.size(170.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.size(150.dp)) {
                            val strokeWidth = 14.dp.toPx()
                            val arcRadius = size.minDimension / 2 - strokeWidth / 2

                            // Background Track (240 degrees from 150 deg)
                            drawArc(
                                color = Color(0xFF1F183D),
                                startAngle = 150f,
                                sweepAngle = 240f,
                                useCenter = false,
                                topLeft = Offset(strokeWidth / 2, strokeWidth / 2),
                                size = Size(arcRadius * 2, arcRadius * 2),
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )

                            // Foreground Gradient Arc
                            val sweep = (analytics.safetyScore / 100f) * 240f
                            val arcColor = when {
                                analytics.safetyScore >= 80f -> SuccessGreen
                                analytics.safetyScore >= 60f -> WarningAmber
                                else -> AlertRed
                            }

                            drawArc(
                                color = arcColor,
                                startAngle = 150f,
                                sweepAngle = sweep.coerceIn(5f, 240f),
                                useCenter = false,
                                topLeft = Offset(strokeWidth / 2, strokeWidth / 2),
                                size = Size(arcRadius * 2, arcRadius * 2),
                                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${analytics.safetyScore.toInt()}%",
                                color = TextPrimary,
                                fontSize = 32.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = if (analytics.safetyScore >= 80f) "SAFE HARBOR" else if (analytics.safetyScore >= 60f) "MODERATE" else "HIGH RISK",
                                color = if (analytics.safetyScore >= 80f) SuccessGreen else if (analytics.safetyScore >= 60f) WarningAmber else AlertRed,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "AI real-time stream protection shielding toxic cyberbullying",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // 2x2 Metric Cards Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatMetricCard(
                        title = "Total Scanned",
                        value = "${analytics.totalScanned}",
                        icon = Icons.Default.Security,
                        accentColor = CyberCyan,
                        subtitle = "Real-time feed",
                        modifier = Modifier.weight(1f)
                    )
                    StatMetricCard(
                        title = "Quarantined",
                        value = "${analytics.quarantinedCount}",
                        icon = Icons.Default.Block,
                        accentColor = AlertRed,
                        subtitle = "Auto-isolated",
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    StatMetricCard(
                        title = "User Warnings",
                        value = "${analytics.warnedCount}",
                        icon = Icons.Default.Warning,
                        accentColor = WarningAmber,
                        subtitle = "Strikes issued",
                        modifier = Modifier.weight(1f)
                    )
                    val violationRate = if (analytics.totalScanned > 0) {
                        ((analytics.quarantinedCount + analytics.warnedCount).toFloat() / analytics.totalScanned * 100).toInt()
                    } else 0
                    StatMetricCard(
                        title = "Violation Rate",
                        value = "$violationRate%",
                        icon = Icons.Default.Speed,
                        accentColor = NeonPurple,
                        subtitle = "Of all chat volume",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Live Toxicity Trend Line Chart
        item {
            CyberCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = CyberBorder
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "LIVE TOXICITY TREND (ROLLING WINDOW)",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(AlertRed))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Toxicity", color = TextMuted, fontSize = 10.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Line Chart on Canvas
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                    ) {
                        val points = analytics.recentToxicityPoints
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val w = size.width
                            val h = size.height

                            // Draw horizontal reference lines: Safe (0.3), Warn (0.5), Quarantine (0.7)
                            val y70 = h * (1f - 0.70f)
                            val y45 = h * (1f - 0.45f)

                            drawLine(
                                color = AlertRed.copy(alpha = 0.3f),
                                start = Offset(0f, y70),
                                end = Offset(w, y70),
                                strokeWidth = 1.dp.toPx()
                            )
                            drawLine(
                                color = WarningAmber.copy(alpha = 0.3f),
                                start = Offset(0f, y45),
                                end = Offset(w, y45),
                                strokeWidth = 1.dp.toPx()
                            )

                            if (points.size >= 2) {
                                val stepX = w / (points.size - 1)
                                val path = Path()
                                val fillPath = Path()

                                points.forEachIndexed { i, score ->
                                    val x = i * stepX
                                    val y = h * (1f - score.coerceIn(0.05f, 0.95f))

                                    if (i == 0) {
                                        path.moveTo(x, y)
                                        fillPath.moveTo(x, h)
                                        fillPath.lineTo(x, y)
                                    } else {
                                        path.lineTo(x, y)
                                        fillPath.lineTo(x, y)
                                    }
                                }

                                fillPath.lineTo(w, h)
                                fillPath.close()

                                // Draw gradient area under curve
                                drawPath(
                                    path = fillPath,
                                    brush = Brush.verticalGradient(
                                        colors = listOf(
                                            NeonPurple.copy(alpha = 0.35f),
                                            Color.Transparent
                                        )
                                    )
                                )

                                // Draw line
                                drawPath(
                                    path = path,
                                    color = CyberCyan,
                                    style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                                )

                                // Draw dots
                                points.forEachIndexed { i, score ->
                                    val x = i * stepX
                                    val y = h * (1f - score.coerceIn(0.05f, 0.95f))
                                    val dotColor = if (score >= 0.70f) AlertRed else if (score >= 0.45f) WarningAmber else SuccessGreen
                                    drawCircle(
                                        color = dotColor,
                                        radius = 4.dp.toPx(),
                                        center = Offset(x, y)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Past 15 comments", color = TextMuted, fontSize = 10.sp)
                        Text(text = "Red line = 70% auto-quarantine", color = TextMuted, fontSize = 10.sp)
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Sentiment Distribution Bar
        item {
            CyberCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = CyberBorder
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "SENTIMENT RATIO BREAKDOWN",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    val totalSentiment = (analytics.positiveCount + analytics.neutralCount + analytics.negativeCount).coerceAtLeast(1)
                    val posPercent = (analytics.positiveCount.toFloat() / totalSentiment * 100).toInt()
                    val neuPercent = (analytics.neutralCount.toFloat() / totalSentiment * 100).toInt()
                    val negPercent = 100 - posPercent - neuPercent

                    // Stacked horizontal bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(6.dp))
                    ) {
                        if (posPercent > 0) {
                            Box(
                                modifier = Modifier
                                    .weight(posPercent.toFloat())
                                    .fillMaxSize()
                                    .background(SuccessGreen)
                            )
                        }
                        if (neuPercent > 0) {
                            Box(
                                modifier = Modifier
                                    .weight(neuPercent.toFloat())
                                    .fillMaxSize()
                                    .background(TextMuted)
                            )
                        }
                        if (negPercent > 0) {
                            Box(
                                modifier = Modifier
                                    .weight(negPercent.toFloat().coerceAtLeast(1f))
                                    .fillMaxSize()
                                    .background(AlertRed)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(SuccessGreen))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Positive: $posPercent%", color = TextSecondary, fontSize = 11.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(TextMuted))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Neutral: $neuPercent%", color = TextSecondary, fontSize = 11.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(AlertRed))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Negative: $negPercent%", color = TextSecondary, fontSize = 11.sp)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Harassment Category Breakdown List
        item {
            CyberCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = CyberBorder
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "INTERCEPTED HARASSMENT CATEGORIES",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    listOf(
                        HarassmentCategory.CYBERBULLYING,
                        HarassmentCategory.HATE_SPEECH,
                        HarassmentCategory.HARASSMENT,
                        HarassmentCategory.THREAT,
                        HarassmentCategory.PROFANITY,
                        HarassmentCategory.SPAM
                    ).forEach { category ->
                        val count = analytics.harassmentCounts[category] ?: 0
                        val maxCount = (analytics.quarantinedCount + analytics.warnedCount).coerceAtLeast(1)
                        val fraction = (count.toFloat() / maxCount).coerceIn(0f, 1f)

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(Color(category.colorHex))
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = category.displayName,
                                color = TextPrimary,
                                fontSize = 12.sp,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "$count hits",
                                color = Color(category.colorHex),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
