package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.Comment
import com.example.model.HarassmentCategory
import com.example.model.ModerationStatus
import com.example.model.RiskLevel
import com.example.model.StreamPlatform
import com.example.ui.components.CategoryChip
import com.example.ui.components.CyberCard
import com.example.ui.components.LivePulseDot
import com.example.ui.components.ModerationStatusBadge
import com.example.ui.components.RiskBadge
import com.example.ui.components.SentimentIndicator
import com.example.ui.components.ToxicityProgressBar
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CyberBgDark
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceDark
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.PurpleBlueGradient
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.CommentFilter
import com.example.ui.viewmodel.HarassGuardViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StreamScreen(
    viewModel: HarassGuardViewModel,
    modifier: Modifier = Modifier
) {
    val comments by viewModel.filteredComments.collectAsState()
    val isStreaming by viewModel.isStreaming.collectAsState()
    val streamSpeedMs by viewModel.streamSpeedMs.collectAsState()
    val currentPlatform by viewModel.currentPlatform.collectAsState()
    val selectedFilter by viewModel.selectedFilter.collectAsState()
    val autoModConfig by viewModel.autoModConfig.collectAsState()

    var showInjectBar by remember { mutableStateOf(false) }
    var injectUsername by remember { mutableStateOf("") }
    var injectText by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBgDark)
            .testTag("stream_screen_list"),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        // Hero Live Monitor Header
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                // Background image
                Image(
                    painter = painterResource(id = R.drawable.img_shield_banner),
                    contentDescription = "Cyber security command shield",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                // Dark gradient overlay
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    CyberBgDark.copy(alpha = 0.7f),
                                    CyberBgDark
                                )
                            )
                        )
                )

                // Shield telemetry header
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(CyberSurfaceDark.copy(alpha = 0.85f))
                                .border(1.dp, CyberCyan.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            LivePulseDot(isActive = isStreaming)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isStreaming) "LIVE STREAM DEFENSE ACTIVE" else "MONITORING PAUSED",
                                color = if (isStreaming) SuccessGreen else WarningAmber,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }

                        // Auto-mod badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(NeonPurple.copy(alpha = 0.25f))
                                .border(1.dp, NeonPurple.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (autoModConfig.autoModEnabled) "AUTO-MOD: ON (<15ms)" else "AUTO-MOD: OFF",
                                color = TextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // Channel info & quick stats
                    Column {
                        Text(
                            text = "Realtime-Streaming Harass Guard",
                            color = TextPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Intercepting toxic harassment, threats, and cyberbullying across live video chat",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Platform Switcher Bar
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StreamPlatform.values().forEach { platform ->
                    val isSelected = currentPlatform == platform
                    val badgeColor = Color(platform.badgeColorHex)

                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { viewModel.setPlatform(platform) }
                            .testTag("platform_chip_${platform.name.lowercase()}"),
                        color = if (isSelected) badgeColor.copy(alpha = 0.25f) else CyberSurfaceDark,
                        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, badgeColor) else androidx.compose.foundation.BorderStroke(1.dp, CyberBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(badgeColor)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = platform.displayName,
                                color = if (isSelected) TextPrimary else TextSecondary,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }
        }

        // Stream Controls & Filters
        item {
            CyberCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Play/Pause button
                        Button(
                            onClick = { viewModel.toggleStreaming() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isStreaming) CyberSurfaceElevated else NeonPurple
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("stream_toggle_button")
                        ) {
                            Icon(
                                imageVector = if (isStreaming) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isStreaming) "Pause" else "Play",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isStreaming) "Pause Feed" else "Resume Feed",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Stream Speed Switcher
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(CyberSurfaceDark)
                                .padding(2.dp)
                        ) {
                            listOf(
                                2500L to "1x",
                                1600L to "2x",
                                600L to "Fast"
                            ).forEach { (speed, label) ->
                                val isSpeedSelected = streamSpeedMs == speed
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSpeedSelected) CyberCyan.copy(alpha = 0.25f) else Color.Transparent)
                                        .clickable { viewModel.setStreamSpeed(speed) }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = label,
                                        color = if (isSpeedSelected) CyberCyan else TextMuted,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        // Inject custom comment toggle
                        IconButton(
                            onClick = { showInjectBar = !showInjectBar },
                            modifier = Modifier.testTag("inject_toggle_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Inject test comment",
                                tint = NeonPurple
                            )
                        }
                    }

                    // Expandable Test Comment Inject Bar
                    AnimatedVisibility(
                        visible = showInjectBar,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 10.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(CyberSurfaceDark)
                                .padding(10.dp)
                        ) {
                            Text(
                                text = "Inject Test Message to Stream:",
                                fontSize = 12.sp,
                                color = TextSecondary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            // Quick Presets
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf(
                                    "You are pathetic loser kys" to "Cyberbully",
                                    "Doxx alert find your IP address" to "Threat",
                                    "Hype clutch play W stream!" to "Clean Fan",
                                    "Disgusting freak leave the lobby" to "Hate Speech"
                                ).forEach { (sampleMsg, sampleLabel) ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(CyberSurfaceCard)
                                            .border(1.dp, CyberBorder, RoundedCornerShape(6.dp))
                                            .clickable {
                                                injectText = sampleMsg
                                                injectUsername = "TestUser_${(10..99).random()}"
                                            }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(text = sampleLabel, fontSize = 10.sp, color = CyberCyan)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = injectText,
                                    onValueChange = { injectText = it },
                                    placeholder = { Text("Enter message text...", fontSize = 12.sp) },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("inject_text_input"),
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = NeonPurple,
                                        unfocusedBorderColor = CyberBorder
                                    )
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Button(
                                    onClick = {
                                        if (injectText.isNotBlank()) {
                                            viewModel.injectCustomComment(injectUsername, injectText)
                                            injectText = ""
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("inject_send_button")
                                ) {
                                    Icon(imageVector = Icons.Default.Send, contentDescription = "Send", modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Filters
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CommentFilter.values().forEach { filter ->
                            val isFilterSelected = selectedFilter == filter
                            FilterChip(
                                selected = isFilterSelected,
                                onClick = { viewModel.setFilter(filter) },
                                label = {
                                    Text(
                                        text = filter.label,
                                        fontSize = 11.sp,
                                        fontWeight = if (isFilterSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = NeonPurple.copy(alpha = 0.25f),
                                    selectedLabelColor = TextPrimary
                                )
                            )
                        }
                    }
                }
            }
        }

        // Comments Count Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Live Stream Comments (${comments.size})",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Auto-quarantining at ${(autoModConfig.deleteThreshold * 100).toInt()}%+",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }
        }

        // Live Comment List
        items(
            items = comments,
            key = { it.id }
        ) { comment ->
            CommentStreamCard(
                comment = comment,
                onQuarantine = { viewModel.quarantineComment(comment.id) },
                onAllow = { viewModel.allowComment(comment.id) },
                onWarn = { viewModel.warnUser(comment.username) },
                onTimeout = { viewModel.timeoutUser(comment.username) },
                onBan = { viewModel.banUser(comment.username) },
                onReport = { viewModel.openReportDialog(comment) }
            )
        }
    }
}

@Composable
fun CommentStreamCard(
    comment: Comment,
    onQuarantine: () -> Unit,
    onAllow: () -> Unit,
    onWarn: () -> Unit,
    onTimeout: () -> Unit,
    onBan: () -> Unit,
    onReport: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isExpanded by remember { mutableStateOf(false) }
    val timeFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
    val formattedTime = remember(comment.timestamp) { timeFormat.format(Date(comment.timestamp)) }

    val isQuarantined = comment.moderationStatus == ModerationStatus.QUARANTINED || comment.moderationStatus == ModerationStatus.BLOCKED
    val isCritical = comment.riskLevel == RiskLevel.CRITICAL || comment.riskLevel == RiskLevel.HIGH_RISK

    val cardBorder = when {
        isQuarantined -> AlertRed.copy(alpha = 0.5f)
        isCritical -> WarningAmber.copy(alpha = 0.45f)
        else -> CyberBorder
    }

    CyberCard(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp)
            .clickable { isExpanded = !isExpanded }
            .testTag("comment_card_${comment.id}"),
        borderColor = cardBorder,
        backgroundColor = if (isQuarantined) CyberSurfaceDark.copy(alpha = 0.95f) else CyberSurfaceCard
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // User Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Avatar circle
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color(comment.avatarColorHex)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = comment.username.take(1).uppercase(),
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Username & Platform
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = comment.username,
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(comment.platform.badgeColorHex).copy(alpha = 0.2f))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = comment.platform.displayName,
                                color = Color(comment.platform.badgeColorHex),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                    Text(
                        text = formattedTime,
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }

                // Badges
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    RiskBadge(riskLevel = comment.riskLevel)
                    ModerationStatusBadge(status = comment.moderationStatus)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Comment Body (masked if quarantined and not expanded)
            if (isQuarantined && !isExpanded) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(AlertRed.copy(alpha = 0.12f))
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Block,
                        contentDescription = "Quarantined",
                        tint = AlertRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Message automatically quarantined by HarassGuard AI (Tap to reveal)",
                        color = AlertRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            } else {
                Text(
                    text = comment.text,
                    color = if (isQuarantined) TextSecondary.copy(alpha = 0.8f) else TextPrimary,
                    fontSize = 14.sp,
                    lineHeight = 19.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Metrics row: Toxicity Progress + Sentiment
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ToxicityProgressBar(
                    score = comment.toxicityScore,
                    modifier = Modifier.weight(1f),
                    label = "Toxicity"
                )
                Spacer(modifier = Modifier.width(12.dp))
                SentimentIndicator(sentiment = comment.sentiment)
            }

            // Categories chips
            if (comment.categories.isNotEmpty() && !comment.categories.contains(HarassmentCategory.NONE)) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    comment.categories.forEach { cat ->
                        CategoryChip(category = cat)
                    }
                }
            }

            // Expanded AI details & Action Controls
            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(CyberSurfaceDark)
                        .padding(10.dp)
                ) {
                    // AI Explanation
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = CyberCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = comment.aiExplanation,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }

                    if (comment.offendingTokens.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.horizontalScroll(rememberScrollState())
                        ) {
                            Text(text = "Tokens: ", color = TextMuted, fontSize = 11.sp)
                            comment.offendingTokens.forEach { token ->
                                Box(
                                    modifier = Modifier
                                        .padding(horizontal = 2.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(AlertRed.copy(alpha = 0.2f))
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Text(text = token, color = AlertRed, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Moderator Quick Actions
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        if (!isQuarantined) {
                            OutlinedButton(
                                onClick = onQuarantine,
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = AlertRed),
                                border = androidx.compose.foundation.BorderStroke(1.dp, AlertRed.copy(alpha = 0.5f))
                            ) {
                                Icon(Icons.Default.Block, null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Quarantine", fontSize = 11.sp)
                            }
                        } else {
                            OutlinedButton(
                                onClick = onAllow,
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = SuccessGreen),
                                border = androidx.compose.foundation.BorderStroke(1.dp, SuccessGreen.copy(alpha = 0.5f))
                            ) {
                                Icon(Icons.Default.CheckCircle, null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Restore", fontSize = 11.sp)
                            }
                        }

                        OutlinedButton(
                            onClick = onWarn,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = WarningAmber),
                            border = androidx.compose.foundation.BorderStroke(1.dp, WarningAmber.copy(alpha = 0.5f))
                        ) {
                            Icon(Icons.Default.Warning, null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Warn", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = onTimeout,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberBlue),
                            border = androidx.compose.foundation.BorderStroke(1.dp, CyberBlue.copy(alpha = 0.5f))
                        ) {
                            Text("Timeout (30s)", fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = onBan,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AlertRed),
                            border = androidx.compose.foundation.BorderStroke(1.dp, AlertRed.copy(alpha = 0.5f))
                        ) {
                            Text("Ban User", fontSize = 11.sp)
                        }

                        Button(
                            onClick = onReport,
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                        ) {
                            Icon(Icons.Default.ReportProblem, null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Report Incident", fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}
