package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val CyberBgDark = Color(0xFF0A0716)
val CyberSurfaceDark = Color(0xFF130E26)
val CyberSurfaceVariant = Color(0xFF1D163A)
val CyberSurfaceCard = Color(0xFF241C47)
val CyberSurfaceElevated = Color(0xFF2E2459)

val NeonPurple = Color(0xFF8B5CF6)
val NeonPurpleDeep = Color(0xFF7C3AED)
val NeonPurpleBright = Color(0xFFA855F7)
val NeonPurpleGlow = Color(0xFFC084FC)

val CyberBlue = Color(0xFF3B82F6)
val CyberBlueDeep = Color(0xFF2563EB)
val CyberCyan = Color(0xFF06B6D4)
val CyberCyanGlow = Color(0xFF22D3EE)

val AlertRed = Color(0xFFEF4444)
val AlertRedGlow = Color(0xFFF87171)
val AlertRedDark = Color(0xFF450A0A)

val WarningAmber = Color(0xFFF59E0B)
val WarningAmberGlow = Color(0xFFFBBF24)

val SuccessGreen = Color(0xFF10B981)
val SuccessGreenGlow = Color(0xFF34D399)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFFCBD5E1)
val TextMuted = Color(0xFF64748B)

val CyberBorder = Color(0x33A855F7)
val CyberBorderBlue = Color(0x3338BDF8)

// Gradients
val PurpleBlueGradient = Brush.horizontalGradient(
    colors = listOf(NeonPurple, CyberBlue)
)

val PurpleCyanGradient = Brush.horizontalGradient(
    colors = listOf(NeonPurpleDeep, CyberCyan)
)

val AlertGradient = Brush.horizontalGradient(
    colors = listOf(AlertRed, Color(0xFFDB2777))
)

val DarkSurfaceGradient = Brush.verticalGradient(
    colors = listOf(CyberSurfaceDark, CyberBgDark)
)
