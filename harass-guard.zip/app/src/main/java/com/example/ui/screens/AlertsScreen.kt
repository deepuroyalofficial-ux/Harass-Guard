package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AlertSeverity
import com.example.model.CyberAlert
import com.example.ui.components.CategoryChip
import com.example.ui.components.CyberCard
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CyberBgDark
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberSurfaceCard
import com.example.ui.theme.CyberSurfaceDark
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.HarassGuardViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AlertsScreen(
    viewModel: HarassGuardViewModel,
    modifier: Modifier = Modifier
) {
    val alerts by viewModel.alerts.collectAsState()
    val autoModConfig by viewModel.autoModConfig.collectAsState()

    var showConfigSection by remember { mutableStateOf(false) }
    var newKeywordText by remember { mutableStateOf("") }

    val unresolvedCount = alerts.count { !it.isResolved }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBgDark)
            .padding(horizontal = 16.dp)
            .testTag("alerts_screen"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp)
    ) {
        // Title & Config Toggle
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(AlertRed.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = null,
                            tint = AlertRed,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Cyberbullying Alerts",
                            color = TextPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$unresolvedCount active alerts require review",
                            color = if (unresolvedCount > 0) AlertRed else SuccessGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                IconButton(
                    onClick = { showConfigSection = !showConfigSection },
                    modifier = Modifier.testTag("toggle_automod_config_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Auto-Mod Settings",
                        tint = if (showConfigSection) CyberCyan else TextSecondary
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
        }

        // Auto-Mod Rule Configuration Card (Expandable)
        item {
            AnimatedVisibility(visible = showConfigSection) {
                CyberCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 14.dp),
                    borderColor = CyberCyan.copy(alpha = 0.4f)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "AUTOMATIC MODERATION ENGINE",
                                color = CyberCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            )
                            Switch(
                                checked = autoModConfig.autoModEnabled,
                                onCheckedChange = {
                                    viewModel.updateAutoModConfig(autoModConfig.copy(autoModEnabled = it))
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = NeonPurple
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Delete / Quarantine Threshold Slider
                        Text(
                            text = "Auto-Quarantine Threshold: ${(autoModConfig.deleteThreshold * 100).toInt()}% toxicity",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Slider(
                            value = autoModConfig.deleteThreshold,
                            onValueChange = {
                                viewModel.updateAutoModConfig(autoModConfig.copy(deleteThreshold = it))
                            },
                            valueRange = 0.50f..0.95f,
                            colors = SliderDefaults.colors(
                                thumbColor = AlertRed,
                                activeTrackColor = AlertRed,
                                inactiveTrackColor = CyberSurfaceDark
                            )
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        // Warn Threshold Slider
                        Text(
                            text = "Auto-Warn Threshold: ${(autoModConfig.warnThreshold * 100).toInt()}% toxicity",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Slider(
                            value = autoModConfig.warnThreshold,
                            onValueChange = {
                                viewModel.updateAutoModConfig(autoModConfig.copy(warnThreshold = it))
                            },
                            valueRange = 0.20f..0.55f,
                            colors = SliderDefaults.colors(
                                thumbColor = WarningAmber,
                                activeTrackColor = WarningAmber,
                                inactiveTrackColor = CyberSurfaceDark
                            )
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Blocked keywords
                        Text(
                            text = "Custom Blocked Keywords (${autoModConfig.blockedKeywords.size}):",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            autoModConfig.blockedKeywords.forEach { kw ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(AlertRed.copy(alpha = 0.2f))
                                        .border(1.dp, AlertRed.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(text = kw, color = AlertRed, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Remove",
                                            tint = AlertRed,
                                            modifier = Modifier
                                                .size(12.dp)
                                                .clickable { viewModel.removeBlockedKeyword(kw) }
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = newKeywordText,
                                onValueChange = { newKeywordText = it },
                                placeholder = { Text("Add trigger keyword...", fontSize = 11.sp) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CyberCyan,
                                    unfocusedBorderColor = CyberBorder
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (newKeywordText.isNotBlank()) {
                                        viewModel.addBlockedKeyword(newKeywordText)
                                        newKeywordText = ""
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Add", tint = Color.Black, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }

        // Action bar: Acknowledge All
        item {
            if (alerts.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "INCIDENT ALERTS FEED",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                    OutlinedButton(
                        onClick = { viewModel.clearAllAlerts() },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberCyan),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.5f)),
                        modifier = Modifier.testTag("clear_all_alerts_button")
                    ) {
                        Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Acknowledge All", fontSize = 11.sp)
                    }
                }
            }
        }

        // Alerts List
        if (alerts.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "No Active Cyberbullying Alerts", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text(text = "HarassGuard is actively monitoring the live stream.", color = TextMuted, fontSize = 12.sp)
                    }
                }
            }
        } else {
            items(
                items = alerts,
                key = { it.id }
            ) { alert ->
                AlertItemCard(
                    alert = alert,
                    onResolve = { action -> viewModel.resolveAlert(alert.id, action) },
                    onBan = { viewModel.banUser(alert.offender); viewModel.resolveAlert(alert.id, "Banned User") }
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
        }
    }
}

@Composable
fun AlertItemCard(
    alert: CyberAlert,
    onResolve: (String) -> Unit,
    onBan: () -> Unit,
    modifier: Modifier = Modifier
) {
    val timeFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
    val formattedTime = remember(alert.timestamp) { timeFormat.format(Date(alert.timestamp)) }

    val severityColor = when (alert.severity) {
        AlertSeverity.CRITICAL -> AlertRed
        AlertSeverity.HIGH -> Color(0xFFF97316)
        AlertSeverity.MEDIUM -> WarningAmber
        AlertSeverity.LOW -> CyberBlue
    }

    CyberCard(
        modifier = modifier.fillMaxWidth(),
        borderColor = if (!alert.isResolved) severityColor.copy(alpha = 0.6f) else CyberBorder.copy(alpha = 0.3f),
        backgroundColor = if (!alert.isResolved) CyberSurfaceCard else CyberSurfaceDark
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Severity Tag + Timestamp
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(severityColor.copy(alpha = 0.2f))
                            .border(1.dp, severityColor.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = alert.severity.label,
                            color = severityColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    CategoryChip(category = alert.category)
                }

                Text(
                    text = formattedTime,
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Offender & Snippet
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Offender: ",
                    color = TextMuted,
                    fontSize = 12.sp
                )
                Text(
                    text = alert.offender,
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Toxicity: ${(alert.toxicityScore * 100).toInt()}%",
                    color = severityColor,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Comment Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberSurfaceDark)
                    .padding(10.dp)
            ) {
                Text(
                    text = "\"${alert.commentSnippet}\"",
                    color = TextSecondary,
                    fontSize = 13.sp,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Actions or Resolved Status
            if (alert.isResolved) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Resolved: ${alert.actionTaken ?: "Action Complete"}",
                        color = SuccessGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onBan,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Block, null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Quarantine & Ban", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { onResolve("Acknowledged & Dismissed") },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Dismiss Alert", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
