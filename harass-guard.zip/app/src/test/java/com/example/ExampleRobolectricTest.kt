package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ai.HarassGuardEngine
import com.example.model.HarassmentCategory
import com.example.model.RiskLevel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Harass Guard", appName)
  }

  @Test
  fun `test toxic comment detection`() {
    val result = HarassGuardEngine.analyze("You are such a pathetic loser uninstall right now")
    assertTrue(result.toxicityScore > 0.5f)
    assertTrue(result.categories.contains(HarassmentCategory.CYBERBULLYING))
  }

  @Test
  fun `test clean comment evaluation`() {
    val result = HarassGuardEngine.analyze("Amazing gameplay, best stream on the platform!")
    assertEquals(RiskLevel.SAFE, result.riskLevel)
    assertTrue(result.toxicityScore < 0.2f)
  }
}
